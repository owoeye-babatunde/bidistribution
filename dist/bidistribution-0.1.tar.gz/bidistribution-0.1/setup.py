from setuptools import setup

setup(name='bidistribution',
      version='0.1',
      description='Gaussian and Binomian distributions',
      packages=['bidistribution'],
      author = 'Babatunde Owoeye',
      author_email = 'owoeyebabatunde01@gmail.com',
      zip_safe=False)
